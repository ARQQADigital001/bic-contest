<?php

class Bic_Custom_Post_type
{
    public function __construct()
    {
        add_action('init', array($this, 'bic_create_custom_post_types'), 101);

    }
    public function bic_create_custom_post_types(){
        $types = [
            //================= Contest Entries =================
            'contest-entries'  => array(
                'rewrite'             => array('slug' => 'contest-entries'),
                'label'               => __('Contest Entries',  BIC_TEXT_DOMAIN),
                'description'         => __('Contest Entries',  BIC_TEXT_DOMAIN),
                'labels'              => array(
                    'name'               => __('Contest Entries', BIC_TEXT_DOMAIN),
                    'singular_name'      => __('Contest Entry',  BIC_TEXT_DOMAIN),
                    'menu_name'          => __('Contest Entries',  BIC_TEXT_DOMAIN),
                    'parent_item_colon'  => __('Contest Entry',  BIC_TEXT_DOMAIN),
                    'all_items'          => __('All Contest Entries',  BIC_TEXT_DOMAIN),
                    'view_item'          => __('View Contest Entry',  BIC_TEXT_DOMAIN),
                    'add_new_item'       => __('Add New Contest Entry',  BIC_TEXT_DOMAIN),
                    'add_new'            => __('Add New',  BIC_TEXT_DOMAIN),
                    'edit_item'          => __('Edit Contest Entry',  BIC_TEXT_DOMAIN),
                    'update_item'        => __('Update Contest Entry',  BIC_TEXT_DOMAIN),
                    'search_items'       => __('Search Contest Entries',  BIC_TEXT_DOMAIN),
                    'not_found'          => __('Not Found',  BIC_TEXT_DOMAIN),
                    'not_found_in_trash' => __('Not found in Trash',  BIC_TEXT_DOMAIN),
                ),
                'supports'            => array('title', 'thumbnail', 'editor'),
                'public'              => true,
                'has_archive'         => false,
                'hierarchical'        => false,
                'show_ui'             => true,
                'show_in_menu'        => true,
                'show_in_nav_menus'   => true,
                'show_in_admin_bar'   => true,
                'can_export'          => true,
                'exclude_from_search' => true,
                'publicly_queryable'  => true,
                'menu_position'       => 10,
            ),
            //================= Contest Entries =================

        ];

        foreach ($types as $type => $args) {
            register_post_type($type, $args);
        }
        register_taxonomy('contest-year', ['contest-entries'], [
            'label' => __('Contest Years', BIC_TEXT_DOMAIN),
            'hierarchical' => false,
            'rewrite' => ['slug' => 'Contest Year'],
            'show_admin_column' => true,
            'show_in_rest' => true,
            'labels' => [
                'singular_name' => __('Contest Year', BIC_TEXT_DOMAIN),
                'all_items' => __('All Contest Years', BIC_TEXT_DOMAIN),
                'edit_item' => __('Edit Contest Year', BIC_TEXT_DOMAIN),
                'view_item' => __('View Contest Year', BIC_TEXT_DOMAIN),
                'update_item' => __('Update Contest Year', BIC_TEXT_DOMAIN),
                'add_new_item' => __('Add New Contest Year', BIC_TEXT_DOMAIN),
                'new_item_name' => __('New Contest Year', BIC_TEXT_DOMAIN),
                'search_items' => __('Search Contest Years', BIC_TEXT_DOMAIN),
                'popular_items' => __('Popular Contest Years', BIC_TEXT_DOMAIN),
                'separate_items_with_commas' => __('Separate Contest Years with comma', BIC_TEXT_DOMAIN),
                'choose_from_most_used' => __('Choose from most used Contest Years', BIC_TEXT_DOMAIN),
                'not_found' => __('No Contest Years found', BIC_TEXT_DOMAIN),
            ]
        ]);
    }
}
/*
 * SELECT
	c.id,
    c.name,
    c.state_code,
    s.name,
    c.country_code,
    cn.name
FROM world.`cities` AS c
LEFT JOIN  world.`states`    AS s  ON c.state_id   = s.id
LEFT JOIN  world.`countries` AS cn ON c.country_id = cn.id
 * */