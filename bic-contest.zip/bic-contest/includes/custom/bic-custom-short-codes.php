<?php

class Bic_Custom_Short_codes
{
    public function __construct()
    {
        add_action('init',array($this,'bic_register_assets'));
        add_shortcode('bic-contest-entry', array($this,'bic_register_shortcode'));
    }
    public function bic_register_shortcode($attrs){
        wp_enqueue_style('bic-contest-entry-shortcode');
        wp_enqueue_script('bic-contest-entry-shortcode');
        if(!is_user_logged_in()){
            ob_start();
            include BIC_PLUGIN_PATH."templates/bic-contest-entry.php";
            return ob_get_clean();

        }else{
            ob_start();
            include BIC_PLUGIN_PATH."templates/bic-dashboard.php";
            return ob_get_clean();
        }

    }
    public function bic_register_assets(){
        wp_register_script( 'bic-contest-entry-shortcode',BIC_PLUGIN_URL.'assets/js/contest-entry.js' , array( 'jquery','select2' ), BIC_VERSION, true );
        wp_register_style( 'bic-contest-entry-shortcode',BIC_PLUGIN_URL.'assets/css/contest-entry.css' ,[], BIC_VERSION, 'all' );
        $this->add_contest_entry();
    }

    private function add_contest_entry()
    {

        if(!is_user_logged_in()&&isset($_POST['consent'])){
            $error = [];
            try{

                foreach ($_FILES["imgs"]["size"] as $i=>$size){
                    $index = $i+1;
                    // Check file size
                    if ($size > 1024000) {
                        $error[] = "image Number {$index} size exceeded max (10MB)";
                    }
                }
                if(empty($error)){
                    $_POST['id'] = $this->save_user();
                    if(!is_wp_error($_POST['id'])) $this ->save_entries($_POST['id']);
                    else $error[]=$_POST['id'];
                }
                wp_safe_redirect( $_POST['current_url'] );
                exit;
            }catch (Exception $e){
                $error[]=$e->getMessage();
            }
            $_POST['errors'] = $error;
        }
    }
    private function save_user()
    {
        $id = wp_insert_user([
            "user_email" => $_POST['email'],
            "user_login" => $_POST['email'],
            "user_nicename" => $_POST['name'],
            "user_pass" => $_POST['password']
        ]);
        if(is_wp_error($id)) return $id;
        update_user_meta($id,'_country','field_66070eef7bfc2');
        update_user_meta($id,'country',[
            "countryCode" => $_POST['acfcs_country'],
            "stateCode"   => $_POST['acfcs_state']
        ]);
        update_user_meta($id,'_nationality','field_660746d95e742');
        update_user_meta($id,'nationality',$_POST['nationality']);
        wp_clear_auth_cookie();
        wp_set_current_user ($id );
        wp_set_auth_cookie  ( $id );
        return $id;
    }
    private function save_entries($id)
    {
        $files     = $_FILES["imgs"]['name'];
        $country_name=acfcs_get_country_name($_POST["acfcs_country"]);
        $attachments=[];
        $post_ids=[];
        foreach ($files as $i=>$file){
            $post_id = wp_insert_post([
                "post_author"  => $id,
                "post_title"   => $_POST["title"],
                "post_content" => $_POST["description"],
                "post_excerpt" => $_POST["description"],
                "post_status"  => "publish",
                "post_type"    => "contest-entries",
            ]);
            $post_ids[]=$post_id;
            $ext = strtolower(pathinfo($file,PATHINFO_EXTENSION));
            //filename: {userId}{postId}-{countryName}({countryCode}).{Ext}
            $fileName="$id$post_id-$country_name({$_POST["acfcs_country"]})";
            $attachment_id = $this->upload_media($_FILES["imgs"]["tmp_name"][$i],$fileName.".$ext",$fileName,"Entry Number $post_id for user $id from {$_POST["acfcs_country"]}");
            set_post_thumbnail( $post_id, $attachment_id );
            $attachments[] = $attachment_id;
        }
        $current_year = date('Y');
        update_user_meta($id,"_attachments_$current_year",$post_ids);
        return $attachments;
    }

    public function upload_media($image_temp,$filename, $name, $alt) {
        $upload_dir   = wp_upload_dir();
        $current_year = date('Y');
        $bic_path     = "/bic-$current_year/{$_POST['acfcs_country']}";
        if(!file_exists($upload_dir["basedir"].$bic_path)){
            mkdir($upload_dir["basedir"].$bic_path,0777,true);
        }
        $direcreate   = wp_mkdir_p($upload_dir["basedir"].$bic_path);
        $file         = $upload_dir["basedir"].$bic_path . '/' . $filename;
        move_uploaded_file($image_temp, $file);
        $wp_filetype  = wp_check_filetype($filename, null);

        $attachment = array(
            'post_mime_type' => $wp_filetype['type'],
            'post_title' => "$alt-$name",
            'post_content' => '',
            'post_status' => 'inherit'
        );
        $attach_id = wp_insert_attachment($attachment, $file);
        require_once( ABSPATH . 'wp-admin/includes/image.php' );
        $attach_data = wp_generate_attachment_metadata($attach_id, $file);
        wp_update_attachment_metadata($attach_id, $attach_data);
        return $attach_id;
    }
}
/*
 * SELECT
	c.id,
    c.name,
    c.state_code,
    s.name,
    c.country_code,
    cn.name,
    cn.region
FROM world.`cities` AS c
LEFT JOIN  world.`states`    AS s  ON c.state_id   = s.id
LEFT JOIN  world.`countries` AS cn ON c.country_id = cn.id
WHERE cn.region = 'Africa'
 * */