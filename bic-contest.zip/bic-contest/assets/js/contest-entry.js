jQuery(document).ready(function ($) {
    let $country = $('select.select2.acfcs__dropdown--countries');
    let $city    = $('select.select2.acfcs__dropdown--states');
    $country.select2({
        allowClear: false,
    });
    $country.on("select2:select", function (e) {
        $city.val(null).trigger("change");
     });
    $country.on("change", function (e) {
        $city.val(null).trigger("change");
     });
    $city.select2({
        allowClear: false,
        ajax: {
            url: city_selector_vars.ajaxurl,
            dataType: 'json',
            type: "POST",
            data: function () {
                return {
                    action: 'get_states_call',
                    country_code: $('select.select2.acfcs__dropdown--countries').select2('val'),
                    post_id: "",
                    show_labels: 1
                };
            },
            processResults: function (data) {
                let result =[];
                data.forEach(function (arrayItem) {
                    result.push({
                        "id": arrayItem.country_state,
                        "text": arrayItem.state_name
                    })
                });
                return {
                        results:result
                };
            }
        }
    });

    $('.upload-img').click(function (e) {
      let $file =  $(this).data('file');
        $("#"+$file).trigger('click');
    });
    $('.file-uploader').on('change', function(event) {
        let $name =  $(this).data('name');
        $("#"+$name).val(event.target.files[0].name);
        let $circle =  $(this).data('circle');
        $("#"+$circle).addClass('hidden');
        console.log("$circle",$circle,"#"+$circle);
        let $img = $(this).data('img');
        let $file = this.files[0];
        if ($file) {
            let reader = new FileReader();
            reader.onload = function (event) {
                $("#"+$img).attr("src", event.target.result);
                $("#"+$img).removeClass('hidden');
            };
            reader.readAsDataURL($file);
        }
    });
});