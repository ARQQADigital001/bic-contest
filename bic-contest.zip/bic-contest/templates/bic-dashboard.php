<?php
acf_form_head();
global $wp;
$current_url = home_url( add_query_arg( array(), $wp->request ) );
$current_year = date('Y');
$entries = get_user_meta(get_current_user_id(),"_attachments_$current_year",true);
$attachments=[];
if($entries){
    foreach ($entries as $entry){
        $attachments[] = wp_get_attachment_url( get_post_thumbnail_id( $entry ));
    }
}
?>
<h2 class="wp-block-post-title"><?php echo __("Dashboard",BIC_TEXT_DOMAIN)?></h2>
<form name="contest-form" id="contest-form" action="<?php echo $current_url; ?>"  method="post" enctype="multipart/form-data">
    <div class="contest-img-upload-container" id="image-upload">
        <?php for($i=0;$i<3;$i++){?>
            <div class="col-4<?php echo $i==2?" last":""; ?>">
                <div class="upload-img" data-file="<?php echo "imgs-file-$i"; ?>">
                    <input type="text" name="<?php echo "imgs[name][$i]"; ?>" id="<?php echo "img-name-$i"; ?>" class="input mb-10 hidden" value="" disabled>
                    <div class="add-container <?php echo $attachments[$i]?"hidden":""?>">
                        <div class="circle" id="<?php echo "img-circle-$i"; ?>">+</div>
                    </div>
                    <div class="img-container">
                        <img src="<?php echo $attachments[$i]?:""?>" class="<?php echo $attachments[$i]?"":"hidden"?> full-width" id="<?php echo "img-$i"; ?>">
                    </div>
                </div>
                <input type="file" accept="image/png, image/jpeg" name="<?php echo "imgs[$i]"; ?>" data-img="<?php echo "img-$i"; ?>" data-circle="<?php echo "img-circle-$i"; ?>" data-name="<?php echo "img-name-$i"; ?>" id="<?php echo "imgs-file-$i"; ?>" class="file-uploader hidden" value="">
            </div>
        <?php } ?>
    </div>
    <p class="contest-submit">
        <input type="hidden" name="current_url" value="<?php echo $current_url; ?>">
        <input type="submit" name="wp-submit" id="wp-submit" class="button button-primary" value="<?php echo __('SUBMIT',BIC_TEXT_DOMAIN)?>">
    </p>
</form>